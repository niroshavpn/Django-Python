# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django import forms

from django.views.decorators.csrf import csrf_protect
from django.shortcuts import render, render_to_response
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.http import HttpResponseForbidden, HttpResponse
from django.core.mail import send_mail
from django.conf import settings
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.views.generic import CreateView, TemplateView, ListView

from HServices.forms import RegisterUserForm, LoginForm, SearchForm, ContactForm, RegisterServiceForm
from django.http import Http404
from django.shortcuts import render,redirect
from django.views import generic
from .models import Service_details, Service_provider
from .filters import Search_Filter
from django.contrib import messages
from django.template.loader import get_template

import django_filters





# Create your views here.
def index(request):
    return render_to_response('index.html')
# -*- coding: utf-8 -*-

class RegisterServiceView(CreateView):
    form_class = RegisterServiceForm
    template_name = "account/service_provider_register.html"

    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated():
            return HttpResponseForbidden()

        return super(RegisterServiceView, self).dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        user = form.save(commit=False)
        user.set_password(form.cleaned_data['password'])
        user.save()
        success_url=reverse_lazy('ProviderRegister')
        messages.success(request, 'Form submission successful')
        return HttpResponse('User registered')

class RegisterUserView(CreateView):
    form_class = RegisterUserForm
    template_name = "account/register.html"

    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated():
            return HttpResponseForbidden()

        return super(RegisterUserView, self).dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        user = form.save(commit=False)
        user.set_password(form.cleaned_data['password'])
        user.save()
        success_url=reverse_lazy('register')
        messages.success(request, 'Form submission successful')
        return HttpResponse('User registered')


class LoginUserView(LoginView):
    form_class = LoginForm
    template_name = "account/login.html"
    redirect_authenticated_user = True
    success_url = reverse_lazy('dashboard')
class SearchDetailsView(ListView):
    form_class = SearchForm
    template_name = "account/search_results.html"

    def get(self, request):
        form = self.form_class(None)
        
        return render(request, self.template_name, {"form": form})

class ContactFormView(ListView):
    form_class = ContactForm
    template_name = "account/contact.html"

    def get(self, request):
        form = self.form_class(None)
        
        return render(request, self.template_name, {"form": form})

def get_select_value(request): 

    if "locationname" or "servicename" in request.POST: 
        locationname1 = request.POST["locationname"] 
        

        servicename1 =request.POST["servicename"]
        serviceprovidername1=Service_details.objects.filter(location_name=locationname1,Service_name=servicename1).values_list('service_provider_name', flat=True).distinct()
        serviceprovidername=list(serviceprovidername1)
    else: 
        locationname1 = None
        servicename1 = None 
 
    return render(request,"account/service_details.html",{'locationname1' : locationname1,'servicename1' : servicename1,'serviceprovidername' : serviceprovidername,'name' : request.user})

def provider_details_view(request):
    if "locationname1" or "servicename1" or "spn" in request.POST:
    
        locationname = request.POST.get('locationname1')
        servicename = request.POST.get("servicename1")
        serviceProvidername = request.POST.get("spn")

        
        subject = "You have Hired a Provider!"
        from_email = settings.DEFAULT_FROM_EMAIL
        #to_email = auth_user.objects.filter(username=request.user).values_list('email')
        to_email = [request.user.email]

        context = {
        'locationname':locationname,
        'servicename':servicename,
        'serviceProvidername':serviceProvidername


        }
        

        HS_message = get_template('account/HS_message.txt').render(context)
        send_mail(subject, HS_message, from_email, to_email, fail_silently=False)
        
    return render(request,"account/hire_success.html",{'locationname':locationname, 'servicename':servicename,'email':to_email,'from_email':from_email})

def contact_view(request):
    if request.method == "POST":
        name = request.POST.get("Name")
        email = request.POST.get("Email")
        message = request.POST.get("Message")

        subject = "Contact Received"
        from_email = email

        #to_email = auth_user.objects.filter(username=request.user).values_list('email')
        to_email = [settings.DEFAULT_FROM_EMAIL]

        contact_Message = "{0}, from {1} with email {2}".format(message, name, email)
        send_mail(subject, contact_Message, from_email, to_email, fail_silently=False)

    return render(request,"account/contact_success.html",{})





@method_decorator(login_required, name='dispatch')
class DashboardView(TemplateView):
    template_name = 'account/dashboard.html'
    
    def dispatch(self, request, *args, **kwargs):
        return super(DashboardView, self).dispatch(request, *args, **kwargs)
