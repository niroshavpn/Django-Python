# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Service_provider(models.Model):
    service_provider_name = models.CharField(max_length=200)
    sp_email = models.EmailField()   
    sp_phone = models.CharField(max_length=10)
    sp_location=models.CharField(max_length=60)
    sp_address = models.CharField(max_length=300)


    def __str__(self):
        return self.service_provider_name
        t = Service_provider.objects.get(id=1)
        t.value = 999  # change field
        t.save() #

class Service_details(models.Model):
    location_name = models.CharField(max_length=100)
    Service_name = models.CharField(max_length=100)
    user_address = models.CharField(max_length=500)
    service_provider_name = models.CharField(max_length=100)



    def __str__(self):
        return '%s %s' % (self.location_name, self.Service_name)



