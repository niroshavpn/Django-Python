from django.conf.urls import url
from django.contrib.auth.views import LogoutView

from HServices.views import SignupForm, LoginUserView, DashboardView, SearchDetailsView,get_select_value, ContactFormView,contact_view, RegisterServiceView
from . import views
from .filters import Search_Filter



urlpatterns = [
    # /account/register
    #url(r'^register/$', views.RegisterUserView, name='register'),
    url(r'^signup/$', views.signup, name='signup'),
    url(r'^activate/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$',
        views.activate, name='activate'),
    #url(r'^register/$', view=RegisterUserView.as_view(), name='register'),
    url(r'^login/$', view=LoginUserView.as_view(), name='login'),
    url(r'^logout/$', view=LogoutView.as_view(), name='logout'),
    url(r'^dashboard/$', view=DashboardView.as_view(), name='dashboard'),

    url(r'^search/$', view=SearchDetailsView.as_view(), name='search'),
    #url(r'^serviceprovider/$', view=SearchProviderView.as_view(), name='serviceprovider'),
	url(r'^service/$', views.get_select_value, name='service'),
	url(r'^serviceProviderdetails/$', views.provider_details_view, name='serviceProviderdetails'),
	url(r'^contact/$', views.contact_view, name='contact'),
	url(r'^contactus/$', view=ContactFormView.as_view(), name='contactus'),

    #url(r'^password_reset/$', 'django.contrib.auth.views.password_reset', name='password_reset'),
    #(r'^password_reset/done/$', 'django.contrib.auth.views.password_reset_done'),
	#(r'^reset/(?P<uidb36>[-\w]+)/(?P<token>[-\w]+)/$', 'django.contrib.auth.views.password_reset_confirm'),
    #(r'^reset/done/$', 'django.contrib.auth.views.password_reset_complete'),
   	url(r'^ProviderRegister/$', views.RegisterServiceView, name='ProviderRegister'),





    #url(r'^search/$', view=DashboardView.as_view(), name='dashboard'),




]
